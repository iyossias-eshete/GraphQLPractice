# Bid
A Graphql, Postgres, Objectionjs implementations of a basic CRUD operation involved in a bidding process. Users will be able to register, signin, create bids, update and delete bids, as well as place bids.
