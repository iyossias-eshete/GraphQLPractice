import fs  from 'fs';
import path from 'path';

const types = [ 'schema'] ;
//const schemaTypes = await Promise.all(types.map(loadTypeSchema));

// const typeReader = async ( schemaPath ) =>{
    
// }
