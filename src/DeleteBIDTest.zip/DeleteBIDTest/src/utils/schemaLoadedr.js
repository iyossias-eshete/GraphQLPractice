"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var types = ['schema'];
//const schemaTypes = await Promise.all(types.map(loadTypeSchema));
// const typeReader = async ( schemaPath ) =>{
// }
